/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author MuhamJ
 */

public class Program {
    public static void main(String[] args){
        // Execute this block to insert data into a table using JDBC api
        /*
        InsertApp b=new InsertApp();
        b.InsertOp();
        */
        
        // Execute this block to delete data from a table using JDBC api
        /*        
        DeleteApp b=new DeleteApp();
        b.DeleteOp();
        */
        
        // Execute this block to query data from a table using JDBC api
        /*
        SelectApp b=new SelectApp();
        b.selectAll();
        */
 
        // Execute this block to update data from a table using JDBC api
        /*
        UpdateApp b=new UpdateApp();
        b.UpdateOp();
        */

        // Execute this block to create new table
        
        CreateNewTable b=new CreateNewTable();
        b.createNewTable();
        
        
        //The following program adds a new material to the materials table and also posts the inventory
        /*
        TransactionApp b=new TransactionApp();
        b.TransactionOp();
        */
        
        
        ;
    }   
}